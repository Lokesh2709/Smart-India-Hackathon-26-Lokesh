
export default function App(){
  return <h1>Government Dashboard Starter</h1>
}
