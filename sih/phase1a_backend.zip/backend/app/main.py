from fastapi import FastAPI
from app.routers.auth_router import router as auth_router
from app.routers.government_router import router as government_router
app=FastAPI(title='SIH Government Dashboard API')
app.include_router(auth_router)
app.include_router(government_router)
@app.get('/')
def root():
    return {'status':'running'}
