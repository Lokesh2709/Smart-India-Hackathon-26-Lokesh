export default function StatCard({ title, value }) {
  return (
    <div className="bg-green-200 rounded-2xl p-6 shadow-lg">
      <h3 className="text-green-900 text-sm">{title}</h3>
      <p className="text-3xl font-bold text-green-950 mt-2">
        {value}
      </p>
    </div>
  );
}
