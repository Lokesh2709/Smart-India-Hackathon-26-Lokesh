export default function DashboardCard({ title, description }) {
  return (
    <div className="bg-green-300 rounded-3xl p-8 shadow-xl hover:scale-105 transition">

      <h2 className="text-2xl font-bold text-green-950 mb-4">
        {title}
      </h2>

      <p className="text-green-900">
        {description}
      </p>

    </div>
  );
}
