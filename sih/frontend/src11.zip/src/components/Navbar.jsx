export default function Navbar() {
  return (
    <div className="bg-green-900 text-white px-8 py-4 shadow-lg">
      <h2 className="text-2xl font-bold">
        National Skill Intelligence Platform
      </h2>
    </div>
  );
}
