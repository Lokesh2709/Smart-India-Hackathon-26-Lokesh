import Navbar from "../components/Navbar";
import DashboardCard from "../components/DashboardCard";
import StatCard from "../components/StatCard";

export default function GovernmentDashboard() {
  return (
    <div className="min-h-screen bg-green-50">
      <Navbar />

      <div className="max-w-7xl mx-auto p-8">

        <h1 className="text-4xl font-bold text-green-900 mb-8">
          Government Representative Dashboard
        </h1>

        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <StatCard title="Students" value="12,845" />
          <StatCard title="Recruiters" value="542" />
          <StatCard title="Skill Gap %" value="23%" />
          <StatCard title="Gov Jobs" value="187" />
        </div>

        <div className="grid md:grid-cols-3 gap-8">

          <DashboardCard
            title="Student Analytics"
            description="Skills, projects, proof-of-work, student performance and employability."
          />

          <DashboardCard
            title="Recruiter Insights"
            description="Industry demands, recruiter requirements and challenge postings."
          />

          <DashboardCard
            title="Skill Gap Analysis"
            description="High demand sectors, low demand sectors and future opportunities."
          />

        </div>
      </div>
    </div>
  );
}
