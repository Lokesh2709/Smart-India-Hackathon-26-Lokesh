import GovernmentDashboard from "./pages/GovernmentDashboard";

function App() {
  return <GovernmentDashboard />;
}

export default App;
