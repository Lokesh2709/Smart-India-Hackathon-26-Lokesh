import api from "../api/api";

export const getDashboard = async () => {
  const response = await api.get("/api/government/dashboard");
  return response.data;
};

export const getTopSkills = async () => {
  const response = await api.get("/api/government/top-skills");
  return response.data;
};
