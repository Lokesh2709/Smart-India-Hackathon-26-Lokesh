import DashboardLayout from "../components/layout/DashboardLayout";
import MetricCard from "../components/cards/MetricCard";
import HubCard from "../components/cards/HubCard";

const Dashboard = () => {
  return (
    <DashboardLayout>

      <div className="grid grid-cols-4 gap-4">

        <MetricCard
          title="Students"
          value="12500"
        />

        <MetricCard
          title="Recruiters"
          value="340"
        />

        <MetricCard
          title="Gov Jobs"
          value="89"
        />

        <MetricCard
          title="Applications"
          value="2430"
        />

      </div>

      <div className="grid grid-cols-3 gap-6 mt-10">

        <HubCard
          title="Student Intelligence Hub"
          description="Skills, projects, proof of work, top performers and student analytics."
        />

        <HubCard
          title="Industry & Recruiter Hub"
          description="Industry requirements, recruiter challenges and hiring demand."
        />

        <HubCard
          title="Skill Gap Analytics"
          description="Demand sectors, shortages, future workforce predictions."
        />

      </div>

    </DashboardLayout>
  );
};

export default Dashboard;
