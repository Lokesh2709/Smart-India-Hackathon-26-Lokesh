import {
  LayoutDashboard,
  Users,
  Building2,
  BarChart3,
  Briefcase
} from "lucide-react";

const Sidebar = () => {
  return (
    <aside
      className="
      w-64
      min-h-screen
      bg-green-300
      p-5
      shadow-xl
      "
    >
      <h1 className="text-2xl font-bold mb-10">
        Gov Portal
      </h1>

      <div className="space-y-6">

        <div className="flex gap-3">
          <LayoutDashboard />
          Dashboard
        </div>

        <div className="flex gap-3">
          <Users />
          Students
        </div>

        <div className="flex gap-3">
          <Building2 />
          Recruiters
        </div>

        <div className="flex gap-3">
          <BarChart3 />
          Analytics
        </div>

        <div className="flex gap-3">
          <Briefcase />
          Jobs
        </div>

      </div>
    </aside>
  );
};

export default Sidebar;
